package com.sistema.doceria.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mysql.cj.xdevapi.Client;
import com.sistema.doceria.model.Cliente;



@Repository
public interface ClienteRepository extends JpaRepository<Client, Long> {

	Cliente save(Cliente cliente);
	
	Cliente listarTodos(Cliente cliente);
	
	Cliente buscarPorId(Cliente cliente);
}
