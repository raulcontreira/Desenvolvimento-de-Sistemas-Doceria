package com.sistema.doceria.dito;

import jdk.jfr.DataAmount;


@DataAmount
public class ProdutoDTO {
    private Long id;
    private String nome;
    private String descricao;
    private Double preco;
    private Integer estoque;
}
