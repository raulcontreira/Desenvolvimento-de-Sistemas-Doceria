package com.sistema.doceria.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sistema.doceria.model.ItemVenda;

@Repository
public interface ItemVendaRepository extends JpaRepository<ItemVenda, Integer>{

	Optional<ItemVenda> deleteAll(Long id);

	void deleteById(Long id);

	Optional<ItemVenda> findAllById(Long id);

	Optional<ItemVenda> findById(Long id);

}
