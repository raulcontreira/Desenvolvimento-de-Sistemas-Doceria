package com.sistema.doceria.dito;


import java.time.LocalDate;

import jdk.jfr.DataAmount;

@DataAmount
public class ClienteDTO {
    private Long id;
    private String nome;
    private String email;
    private String telefone;
    private LocalDate dataCadastro;
}
