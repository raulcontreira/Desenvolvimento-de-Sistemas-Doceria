package com.sistema.doceria.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sistema.doceria.model.ItemVenda;
import com.sistema.doceria.repository.ItemVendaRepository;

@Service
public class ItemVendaService {

	@Autowired
    private ItemVendaRepository repository;

    public List<ItemVenda> listarTodos() {
        return repository.findAll();
    }

    public Optional<ItemVenda> buscarPorId(Long id) {
        return repository.findById(id);
    }

    public ItemVenda salvar(ItemVenda itemvenda) {
        return repository.save(itemvenda);
    }

    public ItemVenda atualizar(Long id, ItemVenda itemvendaAtualizado) {
        return repository.findAllById(id).map(itemvenda -> {
        	itemvenda.setDoce(itemvendaAtualizado.getDoce());
        	itemvenda.setQuantidade(itemvendaAtualizado.getQuantidade());
        	itemvenda.setPreco_unitario(itemvendaAtualizado.getPreco_unitario());
        	itemvenda.setSubtotal(itemvendaAtualizado.getSubtotal());
            return repository.save(itemvenda);
        }).orElseThrow(() -> new RuntimeException("Itemvenda não encontrado"));
    }

    public void deletar(Long id) {
        repository.deleteAll(id);
    }
}

