package com.sistema.doceria.controller;

import com.sistema.doceria.service.ClienteService;
import com.mysql.cj.xdevapi.Client;
import com.sistema.doceria.model.Cliente;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/clientes")
@Tag(name = "Clientes", description = "API para gerenciamento de clientes")
public class ClienteController {

	@Autowired
	private ClienteService service;

	@GetMapping
	@Operation(summary = "Listar todos os clientes")
	public List<Client> listar() {
		return service.listarTodos();
	}

	@GetMapping("/{id}")
	@Operation(summary = "Buscar cliente por ID")
	public ResponseEntity<Cliente> buscar(@PathVariable Long id) {
		return service.buscarPorId(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
	}

	@PostMapping
	@Operation(summary = "Cadastrar um novo cliente")
	public Cliente salvar(@RequestBody Cliente cliente) {
		return service.salvar(cliente);
	}

	@PutMapping("/{id}")
	@Operation(summary = "Atualizar um cliente existente")
	public ResponseEntity<Client> atualizar(@PathVariable Long id, @RequestBody Cliente cliente) {
		try {
			return ResponseEntity.ok(service.atualizar(id, cliente));
		} catch (RuntimeException e) {
			return ResponseEntity.notFound().build();
		}
	}

	@DeleteMapping("/{id}")
	@Operation(summary = "Excluir um cliente")
	public ResponseEntity<Void> deletar(@PathVariable Long id) {
		service.deletar(id);
		return ResponseEntity.noContent().build();
	}
}
