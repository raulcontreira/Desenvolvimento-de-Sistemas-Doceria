package com.sistema.doceria.util;

import org.springframework.stereotype.Component;

@Component
public class MapperUtil {
    // Utilitário para mapeamento de objetos (DTO <-> Entity)
}
