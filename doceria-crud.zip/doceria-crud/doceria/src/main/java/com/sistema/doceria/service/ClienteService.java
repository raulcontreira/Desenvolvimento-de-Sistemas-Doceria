package com.sistema.doceria.service;

import com.mysql.cj.xdevapi.Client;
import com.sistema.doceria.model.Cliente;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sistema.doceria.repository.ClienteRepository;

import java.util.List;
import java.util.Optional;

@Service
public class ClienteService {

    @Autowired
    private ClienteRepository repository;

    public List<Client> listarTodos() {
        return repository.findAll();
    }

    public Optional<Cliente> buscarPorId(Long id) {
        return Optional.empty();
    }

    public Cliente salvar(Cliente cliente) {
        return repository.save(cliente);
    }

    public Client atualizar(Long id, Cliente clienteAtualizado) {
        return repository.findById(id).map(cliente -> {
            ((Cliente) cliente).setNome(clienteAtualizado.getNome());
            ((Cliente) cliente).setEmail(clienteAtualizado.getEmail());
            ((Cliente) cliente).setTelefone(clienteAtualizado.getTelefone());
            ((Cliente) cliente).setEndereco(clienteAtualizado.getEndereco());
            return repository.save(cliente);
        }).orElseThrow(() -> new RuntimeException("Cliente não encontrado"));
    }

    public void deletar(Long id) {
        repository.deleteById(id);
    }
}
