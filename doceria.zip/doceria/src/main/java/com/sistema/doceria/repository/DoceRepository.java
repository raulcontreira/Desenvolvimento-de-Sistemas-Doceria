package com.sistema.doceria.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sistema.doceria.model.Doce;

@Repository
public interface DoceRepository extends JpaRepository<Doce, Integer> {

}
