package com.sistema.doceria.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "usuarios")
public class Usuario {
	
		    @Id
		    @GeneratedValue(strategy = GenerationType.IDENTITY)
		    private Integer id;
		    private String username;
		    private String senha;
		    private String perfil;
			public Integer getId() {
				return id;
			}
			public void setId(Integer id) {
				this.id = id;
			}
			public String getUsername() {
				return username;
			}
			public void setUsername(String username) {
				this.username = username;
			}
			public String getSenha() {
				return senha;
			}
			public void setSenha(String senha) {
				this.senha = senha;
			}
			public String getPerfil() {
				return perfil;
			}
			public void setPerfil(String perfil) {
				this.perfil = perfil;
			}
		    
		    

}
