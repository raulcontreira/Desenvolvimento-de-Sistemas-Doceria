package com.sistema.doceria.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "vendas")
public class Venda {
	
		    @Id
		    @GeneratedValue(strategy = GenerationType.IDENTITY)
		    private Integer id;
		    private String data_venda;
		    
		    @ManyToOne
		    @JoinColumn(name = "usuario_id")
		    private Usuario usuario;

		    @ManyToOne
		    @JoinColumn(name = "cliente_id")
		    private Cliente cliente;
		    
		    private double valor_total;

			public Integer getId() {
				return id;
			}

			public void setId(Integer id) {
				this.id = id;
			}

			public String getData_venda() {
				return data_venda;
			}

			public void setData_venda(String data_venda) {
				this.data_venda = data_venda;
			}

			public Usuario getUsuario() {
				return usuario;
			}

			public void setUsuario(Usuario usuario) {
				this.usuario = usuario;
			}

			public Cliente getCliente() {
				return cliente;
			}

			public void setCliente(Cliente cliente) {
				this.cliente = cliente;
			}

			public double getValor_total() {
				return valor_total;
			}

			public void setValor_total(double valor_total) {
				this.valor_total = valor_total;
			}
		    
		    

}
