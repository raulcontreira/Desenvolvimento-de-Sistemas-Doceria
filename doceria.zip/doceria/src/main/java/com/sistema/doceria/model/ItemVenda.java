package com.sistema.doceria.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "itens_venda")
public class ItemVenda {
	
		    @Id
		    @GeneratedValue(strategy = GenerationType.IDENTITY)
		    private Integer id;
		    
		    @ManyToOne
		    @JoinColumn(name = "venda_id")
		    private Venda venda;

		    @ManyToOne
		    @JoinColumn(name = "doce_id")
		    private Doce doce;
		    
		    private int quantidade;
		    private double preco_unitario;
		    private double subtotal;
		    
			public Integer getId() {
				return id;
			}
			public void setId(Integer id) {
				this.id = id;
			}
			public Venda getVenda() {
				return venda;
			}
			public void setVenda(Venda venda) {
				this.venda = venda;
			}
			public Doce getDoce() {
				return doce;
			}
			public void setDoce(Doce doce) {
				this.doce = doce;
			}
			public int getQuantidade() {
				return quantidade;
			}
			public void setQuantidade(int quantidade) {
				this.quantidade = quantidade;
			}
			public double getPreco_unitario() {
				return preco_unitario;
			}
			public void setPreco_unitario(double preco_unitario) {
				this.preco_unitario = preco_unitario;
			}
			public double getSubtotal() {
				return subtotal;
			}
			public void setSubtotal(double subtotal) {
				this.subtotal = subtotal;
			}
		    
		    

}
