package com.sistema.doceria.service;

public class ClienteService {

}
