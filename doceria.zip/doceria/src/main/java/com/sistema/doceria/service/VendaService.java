package com.sistema.doceria.service;

public class VendaService {

}
