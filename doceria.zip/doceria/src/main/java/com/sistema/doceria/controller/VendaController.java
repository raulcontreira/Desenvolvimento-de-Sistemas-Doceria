package com.sistema.doceria.controller;

public class VendaController {

}
